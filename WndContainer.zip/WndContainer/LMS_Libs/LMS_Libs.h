#pragma once
#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<fstream>
#include<string.h>
#include<conio.h>
#include <cstring>  // for wcscpy_s, wcscat_s
#include <malloc.h>


using namespace std;

wchar_t  bookname[100], auname[50], sc[20], sc1[50];
int q, B, p;

char strTmp[255];// to fix the error

void Lib();
void student(int i);
void pass();
void librarian(int i);
void password(char *str);
void getdata(char *bkName);
void show(int);
void booklist(int);
void modify(int i, char *strbkname);
void see(int, char* bkName);
int branch(int);
void issue(int q, int B, int p);
void der(char *str, int i, int j);
void fine(int, int, int, int, int, int);

extern "C"
{
	typedef struct Buff
	{
		int* iVal;
		char* chVal;

	}MyBuff;

	extern __declspec (dllexport)int fineCalc(int);
	extern __declspec (dllexport) void get(char** chVal);
	extern __declspec (dllexport) void Lms_Intro(MyBuff* buff);
}