﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using System;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Collections.Specialized;

namespace ConsoleApp1
{
    [StructLayout(LayoutKind.Sequential)]
    public struct Buff
    {
        public IntPtr m_iVal;
        public string m_strVal;
    }
    internal class Program
    {
        [DllImport("C:\\CPPReadiness_Workloads\\WndContainer\\x64\\Debug\\LMS_Libs.dll", EntryPoint= "Lms_Intro")]
        private static extern void Lms_Intro(ref Buff i);

        [DllImport("C:\\CPPReadiness_Workloads\\WndContainer\\x64\\Debug\\LMS_Libs.dll", EntryPoint = "get", CallingConvention = CallingConvention.Cdecl)]
        private static extern void get(ref String arr);
        static void Main(string[] args)
        {
            Buff valTemp = new Buff();
            Lms_Intro(ref valTemp);
            //Console.WriteLine(valTemp.());

            string sss = "hello";

            String str=new String(sss.ToString());

            get(ref str);

            //Console.WriteLine(arr);

            //Console.WriteLine(Marshal.ReadIntPtr(valTemp.m_iVal));

            //private static extern int fineCalc(int iDay);
            //int i = fineCalc(2);
            //Console.WriteLine(i);

            //Console.WriteLine("CURRENT  PLATFORM = {0}",
            //Environment.OSVersion.Platform.ToString());
        }
    }
}
