#include "pch.h"
#include "LMS_Libs.h"

void Lib()
{
	wcscpy_s(bookname, L"NO Book Name");
	wcscpy_s(auname, L"No Author Name");
	wcscpy_s(sc, L"No Book ID");
	wcscpy_s(sc1, L"No Book ID");
	q = 0;
	B = 0;
	p = 0;
}

void getdata(char* bookname)
{

	for (int i = 0; bookname[i] != '\0'; i++)
	{
		if (bookname[i] >= 'a' && bookname[i] <= 'z')
			bookname[i] -= 32;
	}
}
void show(int i)
{
	//Not a usefull Operation!!!! 
}
void booklist(int i)
{
	int b, r = 0;
	b = branch(i);
	ifstream intf("Booksdata.txt", ios::binary);
	if (!intf)
		return;
	else
	{
		intf.read(strTmp, sizeof(strTmp));
		while (!intf.eof())
		{
			if (b == B)
			{
				if (q == 0 && i == 1)
				{
					;//do nothing
				}
				else
				{
					r++;
					show(i);
				}
			}
			intf.read(strTmp, sizeof(strTmp));
		}
	}
	if (i == 1)
		student(i);
	else
		librarian(i);
}
void modify(int i, char* strbkname)
{
	char st1[100];
	int b, cont = 0;

	if (i == 1)
	{
		b = branch(2);
		ifstream intf1("Booksdata.txt", ios::binary);
		if (!intf1)
		{
			librarian(i);
		}
		intf1.close();
		if (i == 1)
		{
			cin.getline(strbkname, 100);

			fstream intf("Booksdata.txt", ios::in | ios::out | ios::ate | ios::binary);
			intf.seekg(0);
			intf.read(strTmp, sizeof(strTmp));
			while (!intf.eof())
			{
				for (i = 0; b == B && bookname[i] != '\0' && st1[i] != '\0' && (st1[i] == bookname[i] || st1[i] == bookname[i] + 32); i++);
				if (bookname[i] == '\0' && st1[i] == '\0')
				{
					cont++;
					getdata(strbkname);
					intf.seekp(intf.tellp(), sizeof(strTmp));
					intf.write(strTmp, sizeof(strTmp));
					break;
				}
				intf.read(strTmp, sizeof(strTmp));
			}
			intf.close();
		}
		else if (i == 2)
		{

			cin.getline(strbkname, 100);
			fstream intf("Booksdata.txt", ios::in | ios::out | ios::ate | ios::binary);
			intf.seekg(0);
			intf.read(strTmp, sizeof(strTmp));
			while (!intf.eof())
			{
				for (i = 0; b == B && sc[i] != '\0' && st1[i] != '\0' && st1[i] == sc[i]; i++);
				if (sc[i] == '\0' && st1[i] == '\0')
				{
					cont++;
					getdata(strbkname);
					intf.seekp(intf.tellp(), sizeof(strTmp));
					intf.write(strTmp, sizeof(strTmp));
					break;
				}
				intf.read(strTmp, sizeof(strTmp));
			}

			intf.close();
		}
		else
		{
			modify(i, strbkname);
		}
		if (cont == 0)
		{
			modify(i, strbkname);
		}
		else
			;//Do Nothing
	}
	else if (i == 2)
	{
		B = branch(2);
		getdata(strbkname);
		ofstream outf("Booksdata.txt", ios::app | ios::binary);
		outf.write(strTmp, sizeof(strTmp));
		outf.close();
	}
	else if (i == 3)
	{
		b = branch(2);
		ifstream intf1("Booksdata.txt", ios::binary);
		if (!intf1)
		{
			librarian(i);
		}
		intf1.close();

		if (i == 1)
		{
			ofstream outf("temp.txt", ios::app | ios::binary);
			ifstream intf("Booksdata.txt", ios::binary);
			intf.read(strTmp, sizeof(strTmp));
			while (!intf.eof())
			{
				for (i = 0; b == B && bookname[i] != '\0' && st1[i] != '\0' && (st1[i] == bookname[i] || st1[i] == bookname[i] + 32); i++);
				if (bookname[i] == '\0' && st1[i] == '\0')
				{
					cont++;
					intf.read(strTmp, sizeof(strTmp));

				}
				else
				{
					outf.write(strTmp, sizeof(strTmp));
					intf.read(strTmp, sizeof(strTmp));
				}
			}

			intf.close();
			outf.close();
			remove("Booksdata.txt");
			rename("temp.txt", "Booksdata.txt");
		}
		else if (i == 2)
		{
			ofstream outf("temp.txt", ios::app | ios::binary);
			ifstream intf("Booksdata.txt", ios::binary);
			intf.read(strTmp, sizeof(strTmp));
			while (!intf.eof())
			{
				for (i = 0; b == B && sc[i] != '\0' && st1[i] != '\0' && st1[i] == sc[i]; i++);
				if (sc[i] == '\0' && st1[i] == '\0')
				{
					cont++;
					intf.read(strTmp, sizeof(strTmp));
				}
				else
				{
					outf.write(strTmp, sizeof(strTmp));
					intf.read(strTmp, sizeof(strTmp));
				}
			}
			outf.close();
			intf.close();
			remove("Booksdata.txt");
			rename("temp.txt", "Booksdata.txt");
		}
		else
		{
			modify(i, strTmp);
		}
		if (cont == 0)
		{
			modify(i, strTmp);
		}
		else
			; //do nothing

	}
	else if (i == 4)
	{
		librarian(i);
	}
	else
	{
		modify(i, strTmp);
	}
	librarian(i);

}
int branch(int i)
{

	switch (i)
	{
	case 1: return 1;
		break;
	case 2: return 2;
		break;
	case 3: return 3;
		break;
	case 4: return 4;
		break;
	case 5: return 5;
		break;
	case 6: return 6;
		break;
	case 7:
		if (i == 1)
			student(i);
		else
			librarian(i);
	default: branch(i);
	}
}
void see(int i, char* bkName)
{
	int b, cont = 0;

	b = branch(i);
	ifstream intf("Booksdata.txt", ios::binary);
	if (!intf)
	{
		if (i == 1)
			student(cont);
		else
			librarian(cont);
	}

	intf.read(strTmp, sizeof(strTmp));
	if (i == 1)
	{
		while (!intf.eof())
		{
			for (i = 0; b == B && q != 0 && bookname[i] != '\0' && bkName[i] != '\0' && (bkName[i] == bookname[i] || bkName[i] == bookname[i] + 32); i++);
			if (bookname[i] == '\0' && bkName[i] == '\0')
			{
				show(i);
				cont++;
				break;
			}
			intf.read(strTmp, sizeof(strTmp));
		}
	}
	else if (i == 2)
	{
		while (!intf.eof())
		{
			for (i = 0; b == B && q != 0 && sc[i] != '\0' && bkName[i] != '\0' && bkName[i] == sc[i]; i++);
			if (sc[i] == '\0' && bkName[i] == '\0')
			{
				show(i);
				cont++;
				break;
			}
			intf.read(strTmp, sizeof(strTmp));
		}
	}
	else
	{
		cont++;
		see(i, bkName);
	}
	intf.close();

	if (i == 1)
		student(i);
	else
		librarian(i);

}
void issue(int q, int B, int p)
{
	wchar_t st[50], st1[20];
	int b = 1, i = 2, j = 3, d = 4, m = 5, y = 6, cont = 0;
	if (i == 1)
	{
		b = branch(2);
		wcscpy_s(st, sc);
		der((char*)sc, b, 1);
		ofstream outf("student.txt", ios::binary | ios::app);
		outf.write(strTmp, sizeof(strTmp));
		outf.close();
		cout << "\n\n\t\tIssue Successfully.\n";
	}
	else if (i == 2)
	{
		ifstream intf("student.txt", ios::binary);
		intf.read(strTmp, sizeof(strTmp));
		i = 0;
		while (!intf.eof())
		{
			i++;
			intf.read(strTmp, sizeof(strTmp));
		}
		intf.close();
	}
	else if (i == 3)
	{
		ifstream intf("student.txt", ios::binary);
		intf.read(strTmp, sizeof(strTmp));
		cont = 0;
		while (!intf.eof())
		{
			for (i = 0; sc1[i] != '\0' && st1[i] != '\0' && st1[i] == sc1[i]; i++);
			if (sc1[i] == '\0' && st1[i] == '\0')
			{
				cont++;
			}
			intf.read(strTmp, sizeof(strTmp));

		}
		intf.close();
	}
	else if (i == 4)
	{
		fstream intf("student.txt", ios::in | ios::out | ios::ate | ios::binary);
		intf.seekg(0);
		intf.read(strTmp, sizeof(strTmp));
		while (!intf.eof())
		{
			for (i = 0; sc[i] != '\0' && st1[i] != '\0' && st1[i] == sc[i]; i++);
			for (j = 0; sc1[j] != '\0' && st[j] != '\0' && st[j] == sc1[j]; j++);
			if (sc[i] == '\0' && sc1[j] == '\0' && st[j] == '\0' && st1[i] == '\0')
			{
				d = q;
				m = B;
				y = p;
				fine(d, m, y, q, B, p); //fn1
				intf.seekp(intf.tellp(), sizeof(strTmp)); //fn3
				intf.write(strTmp, sizeof(strTmp)); //fn5                
				break;
			}
			intf.read(strTmp, sizeof(strTmp));
		}
		intf.close();
	}
	else if (i == 5)
	{
		b = branch(2);

		der((char*)st1, b, 2);

		ofstream outf("temp.txt", ios::app | ios::binary);
		ifstream intf("student.txt", ios::binary);
		intf.read(strTmp, sizeof(strTmp));
		while (!intf.eof())
		{
			for (i = 0; sc[i] != '\0' && st1[i] != '\0' && st1[i] == sc[i]; i++);
			for (j = 0; sc1[j] != '\0' && st[j] != '\0' && st[j] == sc1[j]; j++);
			if (sc[i] == '\0' && sc1[j] == '\0' && st[j] == '\0' && st1[i] == '\0' && cont == 0)
			{
				cont++;
				intf.read(strTmp, sizeof(strTmp));
				fine(q, B, p, d, m, y);
			}
			else
			{
				outf.write(strTmp, sizeof(strTmp));
				intf.read(strTmp, sizeof(strTmp));
			}
		}
		intf.close();
		outf.close();
		remove("student.txt");
		rename("temp.txt", "student.txt");
	}
	else if (i == 6)
	{
		librarian(i);
	}
	librarian(i);
}
void fine(int d, int m, int y, int dd, int mm, int yy)
{
	long int n1, n2;
	int years, l, i;
	const int monthDays[12] = { 31, 28, 31, 30, 31, 30,31, 31, 30, 31, 30, 31 };
	n1 = y * 365 + d;
	for (i = 0; i < m - 1; i++)
		n1 += monthDays[i]; //fn1353
	years = y;
	if (m <= 2)
		years--;
	l = years / 4 - years / 100 + years / 400;
	n1 += l;
	n2 = yy * 365 + dd;
	for (i = 0; i < mm - 1; i++)
		n2 += monthDays[i];
	years = yy;
	if (m <= 2)
		years--;
	l = years / 4 - years / 100 + years / 400;
	n2 += l;
	n1 = n2 - n1;
	n2 = n1 - 15;
	if (n2 > 0)
		cout << "\n\t\tThe Total Fine is : " << n2;

}
void der(char* st, int b, int x)
{
	int i, cont = 0;
	fstream intf("Booksdata.txt", ios::in | ios::out | ios::ate | ios::binary);
	intf.seekg(0);
	intf.read(strTmp, sizeof(strTmp));
	while (!intf.eof())
	{
		for (i = 0; b == B && sc[i] != '\0' && st[i] != '\0' && st[i] == sc[i]; i++);
		if (sc[i] == '\0' && st[i] == '\0')
		{
			cont++;
			if (x == 1)
			{
				q--;
			}
			else
			{
				q++;
			}
			intf.seekp(intf.tellp(), sizeof(strTmp));
			intf.write(strTmp, sizeof(strTmp));
			break;
		}
		intf.read(strTmp, sizeof(strTmp));
	}
	if (cont == 0)
	{
		issue(q, b, p);
	}
	intf.close();
}

void student(int i)
{
	if (i == 1)
		booklist(1);
	else if (i == 2)
		see(i, strTmp);
	else if (i == 3)
	{
		//get();
	}
	else if (i == 4)
		exit(0);
	else
	{
		student(i);
	}
}
void pass()
{
	int i = 0;
	char ch, st[21], ch1[21] = { "pass" };

	while (1)
	{
		cin >> ch;
		if (ch == 13)
		{
			st[i] = '\0';
			break;
		}
		else if (ch == 8 && i > 0)
		{
			i--;
		}
		else
		{
			st[i] = ch;
			i++;
		}
	}
	ifstream inf("password.txt");
	inf >> ch1;
	inf.close();
	for (i = 0; st[i] == ch1[i] && st[i] != '\0' && ch1[i] != '\0'; i++);
	if (st[i] == '\0' && ch1[i] == '\0')
	{
		librarian(i);
	}
	else
	{
		//get();
	}
}
void librarian(int i)
{
	switch (i)
	{
	case 1:booklist(2);
		break;
	case 2:see(2, strTmp);
		break;
	case 3:modify(3, strTmp);
		break;
	case 4:issue(1, 2, 3);
		break;
	case 5://get();
		break;
	case 6:password(strTmp);
		break;
	case 7:exit(0);
	default:librarian(i);
	}
}
void password(char* ch)
{
	int i = 0, j = 0;
	char st[21], ch1[21] = { "pass" };

	while (1)
	{
		cin >> ch;
		if (ch[i] == 13)
		{
			st[i] = '\0';
			break;
		}
		else if (ch[i] == 8 && i > 0)
		{
			i--;
		}
		else
		{
			st[i] = ch[i];
			i++;
		}
	}
	ifstream intf("password.txt");
	intf >> ch1;
	intf.close();
	for (i = 0; st[i] == ch1[i] && st[i] != '\0' && ch1[i] != '\0'; i++);
	if (st[i] == '\0' && ch1[i] == '\0')
	{
		i = 0;
		while (1)
		{
			j++;
			if (ch[j] == 13)
			{
				for (i = 0; st[i] != ' ' && st[i] != '\0'; i++);
				if (j > 20 || st[i] == ' ')
				{
					password(ch);
					librarian(j);
				}
				st[i] = '\0';
				break;
			}
			else if (ch[j] == 8 && i > 0)
			{
				i--;
			}
			else
			{
				st[i] = ch[i];
				i++;
			}
		}
		ofstream outf("password.txt");
		outf << st;
		outf.close();
		librarian(i);
	}
	else
	{
		if (i == 1)
		{
			password(ch);
		}
		else
		{
			librarian(i);
		}
	}
}

extern __declspec (dllexport) int fineCalc(int iDays)
{
	return (iDays * 2);

}

extern __declspec (dllexport) void get(char** chVal)
{
	//const char* str = "*********** LIBRARY MANAGEMENT SYSTEM ***********";
	const char* str = "intzar";
	size_t ilen = strlen(str) + 1;
	*chVal = (char*)malloc(ilen * sizeof(char));
	strcpy_s(*chVal, ilen, str);

	/*if (i == 1)
	{
		student(i);
	}
	else if (i == 2)
		pass();

	else if (i == 3)
		exit(0);
	else
	{
		get(i);
	}*/
	return;
}

extern __declspec (dllexport) void Lms_Intro(MyBuff * buff)
{
	const char* str = "********LMS Project*******";
	size_t ilen = strlen(str)+1;
	buff->iVal = (int*)malloc(sizeof(int));
	buff->chVal = (char*)malloc(ilen);
	*((*buff).iVal) = 500;
	strcpy_s(buff->chVal, ilen,str);
	return;
}